#!/bin/bash

NAME=$(echo "$0" | sed 's/.*\///g')

if [[ $NAME =~ template_task.sh ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

SHORT_NAME=$(echo $NAME | awk -F . '{print $1}')

LOG_NAME="report_$SHORT_NAME.log"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен." >> "$LOG_NAME"

echo "$SHORT_NAME[$$]: how much time do I have?" > /tmp/run/cuckoo.pid

read -r MESSAGE < /tmp/run/cuckoo.pid

N=$(echo "$MESSAGE" | awk '{print $4}')

sleep "$N"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $N секунд." >> "$LOG_NAME"
