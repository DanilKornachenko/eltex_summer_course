#!/bin/bash

CONF_FILE="/home/user1/observer.conf"

LOG_FILE="/home/user1/observer.log"

find_proc() {
    for pid in /proc/[0-9]*; do
	if [ -r "$pid/comm" ]; then
	    if grep -qx "$1" "$pid/comm" 2>/dev/null; then
                return 0
	    fi
	fi
    done
    return 1
}

while read line; do
    FILE_PATH="/home/user1/$line"
    if ! find_proc "$FILE_PATH"; then
        nohup "$FILE_PATH" &
	echo "restarting... $line" >> "$LOG_FILE"
    fi
        
done < "$CONF_FILE"
