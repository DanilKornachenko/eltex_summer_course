#!/bin/bash

FIFO_DIR="/tmp/run/"
FIFO_NAME="cuckoo.pid"
FIFO_PATH="$FIFO_DIR/$FIFO_NAME"
LOG_FILE="cockoo.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
}

log_and_answer() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE"
    echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$FIFO_PATH"
}

mkdir -p "$FIFO_DIR"

rm -f "$FIFO_PATH"
rm -f "$LOG_FILE"

mkfifo "$FIFO_PATH"

log "Startup!"

ending() {
    log "Shutdown!"
    rm -f "$FIFO_PATH"
    exit 0
}

# При получении сигнала завершает работу
trap ending SIGTERM

while true; do
    if read -r line < "$FIFO_PATH"; then
        if [[ "$line" =~ .*\[[0-9]*]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
	    NAME=$(echo "$line" | awk -F [ '{print $1}')
	    PID=$(echo "$line" | awk -F [ '{print $2}' | awk -F ] '{print $1}')
	    N=$((RANDOM % 9 + 2))
	    log_and_answer "$NAME[$PID] $N"
	fi
    fi
done
